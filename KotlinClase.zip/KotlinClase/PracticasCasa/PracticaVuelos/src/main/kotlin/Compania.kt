import java.lang.reflect.Array

class Compania {
    val aviones:ArrayList<Avion> = ArrayList()
    val vuelo:ArrayList<Vuelos> = ArrayList()
    val tractores:ArrayList<Tractores> = ArrayList()
    val vueloContadores=1

    init {
        val avion:Avion = Avion("","",1245,124,1)
        aviones.add(avion)

    }
    fun tractorApto(pasajeros:Int,maxPax:Int):Boolean{
        return pasajeros>=maxPax


    }

    fun agregarVuelo(origen:String,destino:String,pasajero:Int,kilometro:Int ): Boolean {
        val avionApto:Vehiculo?=aviones.find { it.apto(12568) }
        val tractorApto:Vehiculo?=tractores.find { it.tractorApto(45) }

        return if (avionApto !=null && tractorApto !=null){
           val vuelo= Vuelos(vueloContadores,origen,destino,pasajero,kilometro)
            vuelo.avion = avionApto as Avion?
            vuelo.tractor = tractorApto as Tractores?
            avionApto.vuelosAsignados
            aviones.add(vuelo)
            
        }else{
            "No existen aviones"
        }



    }

}