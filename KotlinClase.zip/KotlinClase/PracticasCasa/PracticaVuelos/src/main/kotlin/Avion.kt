class Avion(
    matricula:String,
    modelo:String,
    val capLitros:Int,
    val capPax:Int,
    val vuelosAsignados:Int=0

):Vehiculo(matricula,modelo) {
    fun apto(kilometros:Int):Boolean{
        return kilometros>=capLitros
    }
}