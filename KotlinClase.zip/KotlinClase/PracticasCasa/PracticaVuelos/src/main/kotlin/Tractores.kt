class Tractores(
    matricula:String,
    modelo:String,

    val maletas:Int
) :Vehiculo(matricula,modelo){

    fun apto(pasajeros:Int):Boolean{
        return maletas >=pasajeros
    }
}