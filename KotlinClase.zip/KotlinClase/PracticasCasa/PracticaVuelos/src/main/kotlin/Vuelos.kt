class Vuelos(
    val id:Int,
    val origen:String,
    val dstino:String,
    val nMaxPax:Int,
    val kilometros:Int
) {
    var avion: Avion?=null
    var tractor: Tractores?=null


}