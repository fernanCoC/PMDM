open class Vehiculo(
    val matricula:String,
    val modelo:String,
    val tractores:Tractores,
    val aviones: Avion

) {

    fun avionApto(kilometros:Int):Boolean{
        return aviones.capLitros>=kilometros
    }

    fun tractorApto(pasajeros:Int):Boolean {
        return tractores.maletas>=pasajeros
    }

}
