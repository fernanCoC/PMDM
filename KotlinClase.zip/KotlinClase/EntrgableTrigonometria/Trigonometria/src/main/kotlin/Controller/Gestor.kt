package Controller

import model.Circulo
import model.Figuras
import model.Rectangulo
import model.Triangulo

class Gestor {
    val figuras = ArrayList<Figuras>()

    fun mostrarMenu() {
        while (true) {
            println("1. Agregar Circulo")
            println("2. Agregar Rectangulo")
            println("3. Agregar Triangulo")
            println("4. Calcular Area ")
            println("5. Salir ")
            println("Que accion desea realizar: ")

            when (readLine()?.toIntOrNull()) {
                1 -> registrarCirculo()
                2 -> registrarRectangulo()
                3 -> registrarTriangulo()
                4 -> calcularAreas()
                5 -> {
                    println("Saliendo..")
                    return
                }

                else -> println("Opcion no contemplada")
            }


        }
    }

    private fun registrarCirculo() {
        print("Ingresa el radio del círculo: ")
        val radio = readLine()?.toDoubleOrNull()
        if (radio != null) {
            val circulo = Circulo(radio)
            figuras.add(circulo)
            println("Círculo registrado con éxito.")
        } else {
            println("Valor inválido.")
        }
    }

    private fun registrarRectangulo() {
        print("Ingresa la base del rectángulo: ")
        val base = readLine()?.toDoubleOrNull()
        print("Ingresa la altura del rectángulo: ")
        val altura = readLine()?.toDoubleOrNull()

        if (base != null && altura != null) {
            val rectangulo = Rectangulo(base, altura)
            figuras.add(rectangulo)
            println("Rectángulo registrado con éxito.")
        } else {
            println("Valores inválidos.")
        }
    }

    private fun registrarTriangulo() {
        print("Ingresa la base del triángulo: ")
        val base = readLine()?.toDoubleOrNull()
        print("Ingresa la altura del triángulo: ")
        val altura = readLine()?.toDoubleOrNull()

        if (base != null && altura != null) {
            val triangulo = Triangulo(base, altura)
            figuras.add(triangulo)
            println("Triángulo registrado con éxito.")
        } else {
            println("Valores inválidos.")
        }
    }

    private fun calcularAreas() {
        if (figuras.isEmpty()) {
            println("No hay figuras registradas.")
        } else {
            figuras.forEachIndexed { index, figura ->
                println("Figura ${index + 1}: Área = ${figura.calcularArea()}")
            }
        }
    }
}
