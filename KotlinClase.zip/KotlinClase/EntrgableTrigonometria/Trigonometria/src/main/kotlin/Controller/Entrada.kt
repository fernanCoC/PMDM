package Controller

class Entrada {
}
    fun main(){
        val gestor = Gestor()
        gestor.mostrarMenu()
    }
