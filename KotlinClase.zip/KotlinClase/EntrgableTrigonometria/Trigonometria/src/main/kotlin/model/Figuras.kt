package model

abstract class Figuras {
    abstract fun calcularArea():Double
}