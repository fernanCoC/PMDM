package model

import kotlin.math.PI

class Circulo(val radio:Double):Figuras() {
    override fun calcularArea(): Double {
        return PI*radio*radio
    }

    fun calcularDiametro():Double{
        return  2*radio
    }
}