package model

class Rectangulo(val base:Double,val altura:Double):Figuras() {
    override fun calcularArea(): Double {
        return base*altura
    }

    fun calcularPerimetro():Double{
        return 2 * (base + altura)
    }

}