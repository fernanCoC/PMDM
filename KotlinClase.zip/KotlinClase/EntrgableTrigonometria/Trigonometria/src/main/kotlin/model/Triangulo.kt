package model

class Triangulo(val base:Double,val altura:Double):Figuras() {
    override fun calcularArea(): Double {
        return (base * altura)/2
    }

}