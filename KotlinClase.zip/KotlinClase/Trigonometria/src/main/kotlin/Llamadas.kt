abstract class Llamadas(
    val nOrigen: String?,
    val nDestino: String,
    val duracion:Int=0
){
    abstract fun calcularCoste():Double

}

