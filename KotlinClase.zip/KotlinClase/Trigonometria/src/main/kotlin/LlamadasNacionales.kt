class LlamadasNacionales(nOrigen:String,nDestino:String,duracion:Int,val franja:Int):Llamadas(nOrigen, nDestino, duracion) {



    override fun calcularCoste(): Double {
        return when(franja){
            1 ->duracion*0.20
            2 -> duracion*0.3
            3 -> duracion*0.4
            else-> 0.0
        }
    }
}