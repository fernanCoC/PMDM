open class Persona {
   var nombre:String?= null
   var apellido:String?= null
   var edad:Int = 0

   constructor()

   constructor(nombre:String?=null,apellido:String?=null,edad:Int?){
      this.nombre=nombre
      this.apellido=apellido
      this.apellido=apellido
   }

}

class Profesor : Persona{
   var carrera:String?=null
   var pais:String?=null

   constructor():super()

   constructor(nombre: String?,apellido: String?,edad: Int?):super(nombre, apellido, edad)

   constructor(carrera:String?,pais:String?,nombre: String?,apellido: String?,edad: Int?):super(nombre, apellido, edad){
      this.carrera=carrera
      this.pais=pais
   }



}