class Series {
}