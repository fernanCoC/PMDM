class LlamadasLocales(
    nOrigen:String,
    nDestino:String,
    duracion:Int)
    :Llamadas(nOrigen,nDestino,duracion){




    override fun calcularCoste(): Double {
        return 0.0
    }

}