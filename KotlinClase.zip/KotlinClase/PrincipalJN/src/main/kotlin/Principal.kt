

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

fun main(){
    val proceso=ProcessBuilder("cmd.exe","/c","arp -a")
    val ejecucion = proceso.start()

    val leer = BufferedReader(InputStreamReader(ejecucion.inputStream))
   /* proceso .redirectOutput(ProcessBuilder.Redirect.INHERIT)
    val resultado = proceso.start()
    resultado.waitFor()*/

    var  linea : String?
    while (leer.readLine().also { linea = it } !=null)
    {
        println(linea)
    }

}