package controller

class LlamadaProvincial(nOrigen:String, nDestino:String, duracion:Int):Llamadas(nOrigen,nDestino,duracion) {

    companion object{
        const val COSTEsEGUNDO=0.15
    }
    init {
        coste = calcularCoste()
    }
    override fun calcularCoste(): Double {
        return duracion* COSTEsEGUNDO
    }
}