package controller

class Centralita {
    private val listaLlamadas=ArrayList<Llamadas>()

    fun hacerLlamadas(llamada:Llamadas){
        listaLlamadas.add(llamada)
    }

    fun mostrarLlamadas(){
        if (listaLlamadas.isEmpty()){
            println("La lista esta vacia")
        }else{
            listaLlamadas.forEach { llamadas: Llamadas -> println(llamadas)  }
        }

    }
    fun mostrarCostesLlamadas(){
        val costeTot=listaLlamadas.sumOf { it.calcularCoste() }
        println("El coste total de las llamadas es de : $costeTot")
    }
}
